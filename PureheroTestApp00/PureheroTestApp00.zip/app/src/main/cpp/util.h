//
// Created by purehero on 2023-12-13.
//

#ifndef PUREHEROTESTAPP00_UTIL_H
#define PUREHEROTESTAPP00_UTIL_H

#include <sstream>
#include <string>

int bytesToHexString( unsigned char * bytes, int len, std::string & result );

#endif //PUREHEROTESTAPP00_UTIL_H
